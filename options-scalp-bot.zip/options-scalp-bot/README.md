# Options Scalp Bot

**0DTE options scalping — TSLA · NVDA · SPY | Paper Trading Only**

25% Take Profit · 15% Stop Loss · Hard Exit at 3:45pm ET

---

## Overview

Automated 0DTE options scalp bot that:
1. Scores TSLA, NVDA, and SPY each morning using real options market data
2. Selects the single best ticker and direction (CALL or PUT)
3. Waits for high-probability entry conditions before firing
4. Monitors the position and exits on TP, SL, or hard time stop
5. Sends all alerts to Discord

**Paper trading only.** All trades execute against Webull Paper Account `DEN92WP9`.

---

## File Structure

```
options-scalp-bot/
├── scanner/
│   ├── main.py              ← Orchestrates all phases
│   ├── ticker_picker.py     ← Scores TSLA/NVDA/SPY, picks winner
│   ├── entry_timer.py       ← Polls conditions, decides when to enter
│   ├── direction_engine.py  ← CALL or PUT decision (OI skew + momentum)
│   ├── strike_selector.py   ← Finds ATM strike on options chain
│   └── webull_client.py     ← All Webull API calls in one place
├── monitor/
│   └── position_monitor.py  ← Polls price, fires TP/SL/time exit
├── alerts/
│   └── discord.py           ← Formats and sends Discord messages
├── data/
│   ├── active_trade.json    ← Current open position state
│   └── trade_log.csv        ← Full history: ticker, direction, entry, exit, P&L
├── .github/workflows/
│   ├── scalp_scanner.yml    ← Runs at 9:25am EST Mon–Fri
│   └── scalp_monitor.yml    ← Triggered on trade entry, runs until exit
├── requirements.txt
└── README.md
```

---

## GitHub Secrets Required

Go to **Settings → Secrets and variables → Actions → New repository secret** and add:

| Secret Name | Value |
|---|---|
| `WEBULL_APP_ID` | `976790985018314752` |
| `WEBULL_APP_SECRET` | From Webull → API Keys Management → Check |
| `WEBULL_PAPER_ACCOUNT_ID` | `DEN92WP9` |
| `DISCORD_WEBHOOK_ALERTS` | Your `#alerts` channel webhook URL |
| `DISCORD_WEBHOOK_LOG` | Your `#trade-log` channel webhook URL |

---

## Scoring Engine (0–100 pts)

| Factor | Points | What It Measures |
|---|---|---|
| Relative Volume | 30 | Current vol vs. time-normalised 20-day avg |
| OI Concentration near ATM | 25 | OI within ±2 strikes — reactive zone |
| Put/Call OI Skew | 20 | Which direction has smart-money positioning |
| Price Momentum (1-min) | 15 | Last 3 candles — directional clarity |
| ATM Option Liquidity | 10 | Bid/ask spread as % of mid |

---

## Entry Conditions (all four must be simultaneously true)

1. **Past 9:35am ET** — first 5-min candle has closed
2. **Volume confirmation** — current 1-min vol > 1.5× average 1-min vol
3. **ATM spread < 10% of mid** — scalp-friendly spread
4. **OI skew unchanged** — setup hasn't reversed since scoring

Window: **9:30am – 10:15am ET**. If never all true → NO TRADE logged.

---

## Direction Rules (BOTH signals must agree)

**Signal 1 — OI Skew:**
- Heavy CALL OI above price → put wall → **PUT**
- Heavy PUT OI below price → support → **CALL**
- Even → INCONCLUSIVE → **NO TRADE**

**Signal 2 — Price Momentum:**
- Price above VWAP + 3 green candles → **CALL**
- Price below VWAP + 3 red candles → **PUT**
- Mixed → INCONCLUSIVE → **NO TRADE**

---

## Non-Negotiable Rules

| Rule | Enforcement |
|---|---|
| One trade per day maximum | Scanner shuts down immediately after entry |
| No trade is always valid | Bot logs and exits cleanly if conditions don't align |
| Both signals must agree | Conflict = no trade, no exceptions |
| Spread gate enforced | > 10% spread = skip at any point |
| Hard time exit at 3:45pm | Always exits regardless of P&L |
| Paper trading only | All orders to account DEN92WP9 |

---

## Schedule (GitHub Actions)

| Workflow | Cron | What it does |
|---|---|---|
| `scalp_scanner.yml` | `25 14 * * 1-5` (9:25am EST) | Runs ticker picker, waits for entry, fires alert |
| `scalp_monitor.yml` | Triggered by scanner | Polls price every 60s, fires exit alerts |

> **Note:** The cron uses UTC. `14:25 UTC = 9:25am EST`. During EDT (summer), update to `13:25 UTC`.

---

## Discord Alert Examples

**Entry:**
```
🔥 0DTE SCALP ALERT ━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 Ticker:      TSLA
📋 Contract:    TSLA $320 CALL  │  0DTE
💰 Entry Price: $2.40  (mid-price at fill)
🎯 Take Profit: $3.00  (+25%)
🛑 Stop Loss:   $2.04  (-15%)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Score:       87/100
📈 Direction:   CALL
🧠 Reason:      OI put-heavy below + price above VWAP
⏰ Entry Time:  9:47am EST
```

**Exit (TP):**
```
✅ TP HIT — TSLA $320 CALL
Entry: $2.40  →  Exit: $3.00
Result: +25.0% 🔥
Time held: 34 minutes
```
